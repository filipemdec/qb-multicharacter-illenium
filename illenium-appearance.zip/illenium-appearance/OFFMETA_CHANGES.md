# OFFMETA Changes — illenium-appearance (ShopPed 3D mode)

Date: 2026-02-01

## 🎯 Goal
Add an optional **NPC + 3D text prompt** to shop locations (clothing/barber/tattoo/surgeon) when running in **zone mode** (`UseTarget=false`).

## ✅ What was added
- `client/shop_peds_3d.lua`
  - Spawns peds near shops (only inside a configurable distance)
  - Draws 3D title + text above the ped
  - Optional “look at player”
  - Cleans up peds on resource stop
- `shared/config.lua`
  - New `Config.ShopPed3D` section with per-type titles/text and distances

## ⚙️ How to use
- Set `Config.UseTarget = false`
- Ensure `Config.ShopPed3D.enabled = true`
- Configure the text per shop type in `Config.ShopPed3D.types`

## 🧠 Performance notes
- Peds spawn only when players are within `spawnDistance`
- 3D text draws only within `drawDistance`

## 🙏 Credits
- Upstream: iLLeniumStudios / snakewiz
- Feature packaging: OFFMETA
