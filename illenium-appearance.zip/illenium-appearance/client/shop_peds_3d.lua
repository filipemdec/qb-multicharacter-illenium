-- Só faz sentido para o modo "zonas" (UseTarget=false)
if Config.UseTarget then return end
if not Config.ShopPed3D or not Config.ShopPed3D.enabled then return end

local client = client
local ShopPeds = {}

local function DrawText3D(x, y, z, text, scale, font)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end

    SetTextScale(scale, scale)
    SetTextFont(font or 4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
end

local function RequestPedModel(model)
    local hash = type(model) == "string" and joaat(model) or model
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do
        Wait(10)
    end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function CreateShopPedForStore(store)
    local typeCfg = Config.TargetConfig[store.type]
    if not typeCfg then return nil end

    -- Permite override por loja (se já tiveres targetModel/targetScenario)
    local model = store.targetModel or typeCfg.model
    local scenario = store.targetScenario or typeCfg.scenario

    local modelHash = RequestPedModel(model)
    if not modelHash then return nil end

    local coords = store.coords -- vector4
    local ped = CreatePed(0, modelHash, coords.x, coords.y, coords.z - 0.98, coords.w, false, false)

    if scenario and scenario ~= "" then
        TaskStartScenarioInPlace(ped, scenario, true)
    end

    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    PlaceObjectOnGroundProperly(ped)

    SetModelAsNoLongerNeeded(modelHash)
    return ped
end

local function IsAllowedForStore(store)
    -- mesma regra usada nas zonas (job/gang). Se não tiver restrição, é permitido.
    if not store.job and not store.gang then return true end
    local jobName = (store.job and client.job and client.job.name) or (store.gang and client.gang and client.gang.name)
    return jobName == (store.job or store.gang)
end

local function RemovePed(index)
    local ped = ShopPeds[index]
    if ped and DoesEntityExist(ped) then
        DeletePed(ped)
    end
    ShopPeds[index] = nil
end

AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for i in pairs(ShopPeds) do
        RemovePed(i)
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000
        local pedPlayer = PlayerPedId()
        local pCoords = GetEntityCoords(pedPlayer)

        for i, store in ipairs(Config.Stores) do
            local typeTextCfg = Config.ShopPed3D.types[store.type]
            local wantsThisType = typeTextCfg and typeTextCfg.enabled

            if wantsThisType and IsAllowedForStore(store) then
                local sCoords = vector3(store.coords.x, store.coords.y, store.coords.z)
                local dist = #(pCoords - sCoords)

                if dist <= (Config.ShopPed3D.spawnDistance or 25.0) then
                    if not ShopPeds[i] or not DoesEntityExist(ShopPeds[i]) then
                        ShopPeds[i] = CreateShopPedForStore(store)
                    end

                    if ShopPeds[i] and DoesEntityExist(ShopPeds[i]) then
                        if dist <= (Config.ShopPed3D.drawDistance or 15.0) then
                            sleep = 0

                            -- Ped “olha” para o player (como no stand de carros)
                            if Config.ShopPed3D.lookAtPlayer then
                                SetEntityHeading(
                                    ShopPeds[i],
                                    GetHeadingFromVector_2d(pCoords.x - store.coords.x, pCoords.y - store.coords.y)
                                )
                            end

                            local pedCoords = GetEntityCoords(ShopPeds[i])
                            DrawText3D(
                                pedCoords.x, pedCoords.y, pedCoords.z + (Config.ShopPed3D.titleOffset or 2.15),
                                typeTextCfg.title or "",
                                Config.ShopPed3D.titleScale or 0.8,
                                Config.ShopPed3D.font or 4
                            )
                            DrawText3D(
                                pedCoords.x, pedCoords.y, pedCoords.z + (Config.ShopPed3D.textOffset or 1.95),
                                typeTextCfg.text or "",
                                Config.ShopPed3D.textScale or 0.6,
                                Config.ShopPed3D.font or 4
                            )
                        end
                    end
                else
                    -- longe: remove ped
                    if ShopPeds[i] then
                        RemovePed(i)
                    end
                end
            else
                -- se este tipo não está ativo ou player não tem permissão: garante que não fica ped
                if ShopPeds[i] then
                    RemovePed(i)
                end
            end
        end

        Wait(sleep)
    end
end)
