# OFFMETA Changes — qb-multicharacter (illenium-appearance compatibility)

Date: 2026-02-01

## 🎯 Problem
When using **illenium-appearance** as the appearance system, the **multicharacter preview ped** could show incorrect / default clothing when selecting a character.

## ✅ Solution (what was changed)
- The preview ped creation now applies the saved appearance using:
  - `exports['illenium-appearance']:setPedAppearance(charPed, appearanceData)`
- Improved model handling:
  - stored model values can be **numeric hashes** or **string model names**
  - the patch converts either format into a valid model hash before initializing the ped
- Minor safety: ensures ped component defaults are applied before appearance is set

## 🧩 Notes
- This patch focuses on the **character selection preview** experience.
- `illenium-appearance` must be ensured **before** `qb-multicharacter`.

## 🙏 Credits
- Upstream: QBCore Framework contributors
- Compatibility patch: OFFMETA
